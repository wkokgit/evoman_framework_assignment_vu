<?xml version="1.0" encoding="UTF-8"?>
<tileset name="plataform2" tilewidth="32" tileheight="32">
 <image source="evoman/images/plataform2.jpg" width="150" height="93"/>
</tileset>
